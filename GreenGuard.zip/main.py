
# GreenGuard
# Author: Enzo Oliveira
# Purpose: Grain storage risk monitoring system
# Legal note: Prototype – not for direct industrial deployment.

def calculate_risk(temperature, humidity):
    risk = 0
    if temperature > 30:
        risk += 40
    if humidity > 17:
        risk += 40
    if temperature > 35 and humidity > 20:
        risk += 20
    return min(risk, 100)

if __name__ == "__main__":
    risk = calculate_risk(33, 18)
    print(f"Storage risk level: {risk}%")
